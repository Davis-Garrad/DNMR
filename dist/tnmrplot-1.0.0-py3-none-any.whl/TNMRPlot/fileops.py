
import re

import numpy as np
import h5py as hdf

def get_data(fn: str):
    '''Retrieves all the data from an HDF file and stores it in a nice format.

    Parameters
    ----------
        fn: str, the filename of the data. Include file extension.

    Returns
    -------
        a dictionary, in the form { 'reals': [2d numpy array, 1st dimension is sequence index, 2nd dimension is datapoint index],
                                    'imags': [same as reals],
                                    'times': [same as reals],  
                                  }
    '''
    def get_point_info(file, key):
        '''Retrieves all the data associated with a single point - reals, imags, and times.'''
        reals = file[key]['tnmr_reals']
        imags = file[key]['tnmr_imags']
        times = file[key]['tnmr_times']
        return reals, imags, times

    with hdf.File(fn, 'r') as file:
        toplevel = file.keys()
        points = []
        point_indices = []
        for i in toplevel: # get all points
            m = re.match('point(?P<index>[0-9]+)', i)
            if not(m is None):
                points += [ m[0] ]
                point_indices += [ int(m['index']) ]
        points = np.array(points)
        point_indices = np.array(point_indices)
        
        sorted_indices = np.argsort(point_indices)
        points = points[sorted_indices]
        point_indices = point_indices[sorted_indices]
        
        # load the first one, to get sizes etc.
        f_reals, f_imags, f_times = get_point_info(file, points[0])
        reals = np.ndarray(shape=(points.shape[0], f_reals.shape[0]), dtype=f_reals.dtype)
        imags = np.ndarray(shape=(points.shape[0], f_imags.shape[0]), dtype=f_imags.dtype)
        times = np.ndarray(shape=(points.shape[0], f_times.shape[0]), dtype=f_times.dtype)
        reals[0] = f_reals
        imags[0] = f_imags
        times[0] = f_times

        if(len(points) > 1):
            for i, index in zip(points[1:], point_indices[1:]):
                R, I, T = get_point_info(file, i)
                reals[index] = R
                imags[index] = I
                times[index] = T

    return reals, imags, times





