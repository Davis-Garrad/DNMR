
import sys

import numpy as np

import matplotlib as mpl
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *

import TNMRPlot.fileops

class PhaseAdjustmentWidget(QWidget):
    def __init__(self, parent=None, callback=lambda: None):
        super(PhaseAdjustmentWidget, self).__init__(parent)

        self.slider_phase = QSlider()
        self.slider_phase.setRange(-180, 180)
        self.slider_phase.valueChanged.connect(callback)
        self.slider_phase.valueChanged.connect(lambda v: self.label_phase.setText(f'Phase: {v}\u00b0'))
        self.slider_phase.setOrientation(Qt.Orientation.Horizontal)
        self.label_phase = QLabel('Phase: 0\u00b0')

        layout = QVBoxLayout()
        layout.addWidget(self.label_phase)
        layout.addWidget(self.slider_phase)
        self.setLayout(layout)

class FileSelectionWidget(QWidget):
    def __init__(self, parent=None, callback=lambda: None):
        super(FileSelectionWidget, self).__init__(parent)
        
        self.filedialog = QFileDialog()
        self.button_load = QPushButton('Load')
        self.button_load.clicked.connect(self.open_file)
        self.spinbox_index = QSpinBox()

        layout = QVBoxLayout()
        layout.addWidget(self.button_load)
        layout.addWidget(self.spinbox_index)
        self.setLayout(layout)

        self.fn = ''
        self.reals = []
        self.imags = []
        self.times = []

        self.callback = callback
        self.spinbox_index.valueChanged.connect(callback)
    
    def open_file(self):
        try:
            self.fn = self.filedialog.getOpenFileName()[0]
            self.reals, self.imags, self.times = fileops.get_data(self.fn)
            self.spinbox_index.setRange(0, self.reals.shape[0]-1)
            self.spinbox_index.setValue(0)
            self.callback()
        except Exception as e:
            print(str(e))
            print(repr(e))

#class MetaDataPanel(QWidget):
#    def __init__(self, parent=None, callback=lambda: None):
#        super(FileSelectionWidget, self).__init__(parent)
    

class Window(QWidget):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)

        self.fig = Figure()
        self.canvas = FigureCanvas(self.fig)
        self.toolbar = NavigationToolbar(self.canvas, self)
        
        self.fileselector = FileSelectionWidget(callback=self.plot)
        self.phase_adjustment = PhaseAdjustmentWidget(callback=self.plot)
        upper_layout = QHBoxLayout()
        upper_layout.addWidget(self.fileselector)
        upper_layout.addWidget(self.phase_adjustment)

        # layout stuff
        layout = QVBoxLayout()
        layout.addLayout(upper_layout)
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        self.setLayout(layout)

        self.ax = self.fig.add_subplot(111)

    def plot(self):
        if(self.fileselector.fn == ''):
            return
        # save the current zoom for restoring later
        old_x_lim = self.ax.get_xlim()
        old_y_lim = self.ax.get_ylim()

        index = self.fileselector.spinbox_index.value()
        reals = self.fileselector.reals
        imags = self.fileselector.imags
        times = self.fileselector.times

        complexes = reals + 1j*imags
        phase = np.exp(1j*self.phase_adjustment.slider_phase.value() * np.pi/180.0)
        complexes *= phase
        reals = np.real(complexes)
        imags = np.imag(complexes)

        self.ax.clear()
        self.ax.plot(times[index][:reals[index].shape[0]], reals[index], 'r', alpha=0.6, label='R')
        self.ax.plot(times[index][:imags[index].shape[0]], imags[index], 'b', alpha=0.6, label='I')

        self.ax.plot(times[index][:reals[index].shape[0]], np.average(reals, axis=0), 'r--', alpha=0.3, label='Avg. R')
        self.ax.plot(times[index][:imags[index].shape[0]], np.average(imags, axis=0), 'b--', alpha=0.3, label='Avg. I')
        
        # Thanks, azelcer (https://stackoverflow.com/questions/70336467/keep-zoom-and-ability-to-zoom-out-to-current-data-extent-in-matplotlib-pyplot)
        self.ax.relim()
        self.ax.autoscale()
        self.toolbar.update() # Clear the axes stack
        self.toolbar.push_current()  # save the current status as home

        self.ax.set_xlim(old_x_lim)  # and restore zoom
        self.ax.set_ylim(old_y_lim)
        self.ax.legend()

        self.canvas.draw()
        

app = QApplication(sys.argv)
main = Window()
main.show()

app.exec_()
        